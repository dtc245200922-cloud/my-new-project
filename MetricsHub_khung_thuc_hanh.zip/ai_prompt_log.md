# Nhật ký hỗ trợ AI

## Yêu cầu thực tế
Người học cung cấp đề MetricsHub, gồm mã Legacy, checklist và giới hạn sử dụng AI.

## Hỗ trợ đã thực hiện trong lượt này
AI phân tích lựa chọn Flexbox, Grid và Bootstrap; tạo boilerplate Pricing; cung cấp hướng dẫn dạng comment cho Navbar và Dashboard; chuẩn bị bản giải trình và danh sách kiểm tra.

AI chưa viết hoàn chỉnh Navbar hoặc Dashboard, chưa chạy kiểm thử trình duyệt và không khẳng định người học đã hoàn thành các thao tác đó.

## Prompt gợi ý cho các lượt tiếp theo (chưa thực hiện)
- Hướng dẫn dùng flex-wrap và gap để Navbar không tràn khi liên kết có từ dài.
- Giải thích cách đặt một Grid item chiếm hai hàng và hai cột, rồi reset span trên mobile.
- So sánh col-sm-4 và col-md-4 trong Bootstrap 5.

Người học bổ sung prompt, kết quả và nhận xét thực tế sau mỗi lượt sử dụng AI.

# Audit và hướng dẫn hoàn thiện

## Audit
- Navbar trong mã mẫu dùng 200px + 600px + 200px: riêng các track đã rộng 1000px, chưa tính padding. Nội dung dài có thể tràn. Grid không tự nó sai; cách định nghĩa track cứng không phù hợp yêu cầu này.
- Dashboard có hai wrapper .column, mỗi wrapper rộng 50%. Widget không thể span qua hai cột hoặc đồng bộ hai hàng một cách trực tiếp. Đoạn mẫu không thực sự dùng float cho Dashboard, dù comment nói có.
- Pricing dùng float và media query riêng. Cách này có thể hoạt động, nhưng dự án đã có Bootstrap nên tái sử dụng hệ thống lưới sẽ giảm CSS phải bảo trì.

## Việc học viên cần làm
1. Thêm logo, nhóm liên kết và Profile vào header. Dùng Flexbox với wrap và gap; kiểm tra VeryLongGermanWordForDashboard.
2. Thêm bốn widget là con trực tiếp của .grid-dashboard. Dùng Grid ba cột trên desktop; một widget span 2 cột và 2 hàng; các widget còn lại tự sắp xếp.
3. Chuyển Grid sang hai cột trên tablet và một cột trên mobile. Reset span tại breakpoint phù hợp để không tạo cột ngầm.
4. Giữ Pricing bằng Bootstrap, không thêm CSS chia cột. col-md-4 bắt đầu ba cột tại 768px, col-sm-4 bắt đầu tại 576px.
5. Kiểm tra 375px, 768px và 1280px: không cuộn ngang, Navbar không chồng chữ, Dashboard không tràn, Pricing xếp dọc dưới 768px.
6. Dùng Flexbox bên trong widget nếu cần căn biểu tượng với chữ. Với bố cục zig-zag cần điều khiển cả hàng và cột, ưu tiên Grid.
7. Ghi kết quả kiểm thử và các lượt trao đổi AI thực tế; chỉ nộp sau khi hoàn thiện mã.

# Trạng thái
Đây là bộ khung hỗ trợ học viên, chưa phải bài hoàn chỉnh để nộp.

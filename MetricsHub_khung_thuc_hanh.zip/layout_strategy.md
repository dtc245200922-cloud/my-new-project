# Chiến lược dàn trang

Grid phù hợp với bố cục hai chiều: Dashboard cần widget chiếm nhiều hàng hoặc cột nên dùng Grid để định vị trực tiếp, tránh các wrapper trung gian. Flexbox phù hợp với component một chiều như Navbar vì các mục có thể co giãn và xuống dòng theo nội dung. Grid và Flexbox có thể kết hợp: widget là Grid item nhưng bên trong dùng Flexbox để căn biểu tượng và chữ. Đây là lựa chọn theo yêu cầu, không phải quy tắc tuyệt đối. Pricing dùng Bootstrap với `row`, `col-12 col-md-4` để tái sử dụng lưới và breakpoint có sẵn. Dùng `gap` thay cho margin rải rác để khoảng cách đồng đều.
